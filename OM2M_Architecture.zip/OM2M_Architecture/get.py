import requests

headers = {'X-M2M-Origin':'admin:admin', 'Accept':'application/xml'}

response = requests.get("http://127.0.0.1:8080/~/in-cse", headers=headers)
print(response.text)