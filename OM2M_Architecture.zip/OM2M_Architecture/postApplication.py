import requests
import json

headers = {'X-M2M-Origin':'admin:admin', 'Content-type':'application/xml','ty':'2'}
data =  json.dumps({
   "m2m:ae": {
     "api": "app-sensor",
     "rr": "false",
     "lbl": ["Type/sensor", "Category/temperature", "Location/home"],
     "rn": "MY_SENSOR"
   }
 })

response = requests.post("http://127.0.0.1:8080/~/in-cse", data=data, headers=headers)
print(response.text)