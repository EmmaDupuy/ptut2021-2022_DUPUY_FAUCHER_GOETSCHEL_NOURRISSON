import requests
import json

headers = {'X-M2M-Origin':'admin:admin', 'Content-type':'application/xml','ty':'3'}
data =  json.dumps({
   "m2m:cnt": {
     "rn": "DESCRIPTOR"
   }
 })

response = requests.post("http://127.0.0.1:8080/~/in-cse", data=data, headers=headers)
print(response.text)