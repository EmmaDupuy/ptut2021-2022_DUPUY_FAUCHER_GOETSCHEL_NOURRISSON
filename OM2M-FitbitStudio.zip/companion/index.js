fetch('http://127.0.0.1:8080/~/in-cse',
    {
    method: "POST",
  
    headers: {
      "X-M2M-Origin": 'admin:admin',
      "Content-Type": 'application/json;ty=2',
      "Access-Control-Allow-Origin":'*'
    },
  
    body: {
   "m2m:ae": {
     "api": "app-sensor",
     "rr": "false",
     "lbl": ["Type/sensor", "Category/temperature", "Location/home"],
     "rn": "MY_SENSOR_test3"
   }
 }
  
}).then(function(response) {
  return response;
}).catch(function(error) {
  console.log('Il y a eu un problème avec l\'opération fetch: ' + error.stack);
});