
import { display } from "display";
import * as document from "document";

import { geolocation } from "geolocation";


const altitudeData= document.getElementById("altitude-data");
const altitudeLabel=document.getElementById("orientation-label");

var watchID = geolocation.watchPosition(locationSuccess, locationError, { timeout: 60 * 1000 });


function locationSuccess(position) {
  altitudeData.text=position.coords.altitude;
  console.log("Altitude: " + position.coords.altitude+ " mètres");
}

function locationError(error) {
  console.log("Error: " + error.code, "Message: " + error.message);
}


  

